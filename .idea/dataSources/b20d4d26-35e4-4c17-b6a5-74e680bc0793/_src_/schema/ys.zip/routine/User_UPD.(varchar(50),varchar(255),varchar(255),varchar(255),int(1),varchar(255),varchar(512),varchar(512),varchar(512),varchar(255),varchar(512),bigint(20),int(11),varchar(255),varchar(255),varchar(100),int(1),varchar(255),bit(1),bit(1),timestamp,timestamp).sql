CREATE PROCEDURE `User_UPD`(IN `table`                VARCHAR(50), IN `connectionId` VARCHAR(255),
                            IN `providerId`           VARCHAR(255), IN `providerConnectionId` VARCHAR(255),
                            IN `rank`                 INT(1), IN `displayName` VARCHAR(255),
                            IN `profileUrl`           VARCHAR(512), IN `imageUrl` VARCHAR(512),
                            IN `accessToken`          VARCHAR(512), IN `secret` VARCHAR(255),
                            IN `refreshToken`         VARCHAR(512), IN `expireTime` BIGINT(20), IN `id` INT(11),
                            IN `email`                VARCHAR(255), IN `username` VARCHAR(255),
                            IN `password`             VARCHAR(100), IN `roleId` INT(1), IN `str` VARCHAR(255),
                            IN `enabled`              BIT(1), IN `notLocked` BIT(1), IN `createTime` TIMESTAMP,
                            IN `updateTime`           TIMESTAMP, OUT `noOfRow` INT(11))
  BEGIN

  SET @connectionId =`connectionId`;
  SET @providerId =  `providerId`;
  SET @providerConnectionId = `providerConnectionId`;
  SET @rank = `rank`;
  SET @displayName = `displayName`;
  SET @profileUrl = `profileUrl`;
  SET @imageUrl = `imageUrl`;
  SET @accessToken = `accessToken`;
  SET @secret = `secret`;
  SET @refreshToken = `refreshToken`;
  SET @expireTime = `expireTime`;
  SET @id = `id`;
  SET @email = `email`;
  SET @username = `username`;
  SET @password = `password`;
  SET @roleId = `roleId`;
  SET @str = `str`;
  SET @enabled = `enabled`;
  SET @notLocked = `notLocked`;
  SET @createTime = `createTime`;
  SET @updateTime = `updateTime`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
				SET 
                username=@username,
                roleId=@roleId,
                enabled=@enabled,
                notLocked=@notLocked,
                updateTime=@updateTime
                WHERE
                id=@id;
                ');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET @noOfRow='';
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END