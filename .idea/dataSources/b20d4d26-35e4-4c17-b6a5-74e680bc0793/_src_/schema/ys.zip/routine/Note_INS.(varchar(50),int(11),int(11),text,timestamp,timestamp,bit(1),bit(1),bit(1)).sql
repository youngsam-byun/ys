CREATE PROCEDURE `Note_INS`(IN `table`    VARCHAR(50), IN `sendId` INT(11), IN `recvId` INT(11), IN `msg` TEXT,
                            IN `sendTime` TIMESTAMP, IN `recvTime` TIMESTAMP, IN `read` BIT(1), IN `sendDel` BIT(1),
                            IN `recvDel`  BIT(1), OUT `resultId` INT(11))
  BEGIN

SET @sendId=`sendId`;
SET @recvId=`recvId`;
SET @msg=`msg`;
SET @sendTime=`sendTime`;
SET @recvTime=`recvTime`;
SET @read=`read`;
SET @sendDel=`sendDel`;
SET @recvDel=`recvDel`;

SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(`sendId`,`recvId`,`msg`,`sendTime`,`recvTime`,`read`,`sendDel`,`recvDel`)
                VALUES
				(@sendId,@recvId,@msg,@sendTime,@recvTime,@read,@sendDel,@recvDel)
				;');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();


END