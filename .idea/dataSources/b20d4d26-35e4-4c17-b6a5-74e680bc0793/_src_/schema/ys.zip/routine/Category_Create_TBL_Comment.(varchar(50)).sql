CREATE PROCEDURE `Category_Create_TBL_Comment`(IN `table` VARCHAR(50))
  BEGIN

SET @query=CONCAT('CREATE TABLE IF NOT EXISTS  `',`table`,'`  
				 LIKE `comment_template`; '
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
END