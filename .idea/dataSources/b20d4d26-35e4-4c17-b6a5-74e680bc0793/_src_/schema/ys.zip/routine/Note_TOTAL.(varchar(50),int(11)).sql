CREATE PROCEDURE `Note_TOTAL`(IN `table` VARCHAR(50), IN `userId` INT(11), OUT `total` INT(11))
  BEGIN
	
    SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
    
    SET @userId=`userId`;
    
	SET @query=CONCAT('SELECT COUNT(id) INTO @total FROM `',`table`,'` WHERE (sendId=@userId AND sendDel=false) OR (recvId=@userId AND recvDel=false)');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	

	SET `total` = @total;

	SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
    
END