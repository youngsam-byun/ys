CREATE PROCEDURE `Category_Drop_TBL_Comment`(IN `table` VARCHAR(50))
  BEGIN

SET @query=CONCAT('DROP TABLE `',`table`,'` ;');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
END