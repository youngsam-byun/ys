CREATE PROCEDURE `G_readByColumn`(IN `table` VARCHAR(50), IN `columnName` VARCHAR(50), IN `value` VARCHAR(50))
  BEGIN
		
	SET @query=CONCAT('SELECT * FROM `',`table`,'` WHERE `',`columnName`,'` = '',`value`,'' ');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	

END