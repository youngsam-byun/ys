CREATE PROCEDURE `deleteById`(IN `table` VARCHAR(50), IN `id` INT(11), OUT `noOfRow` INT(11))
  BEGIN
	SET @id   = `id`;
	SET @noOfRow ='';

	SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
    PREPARE stmt FROM @query2;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	

	SET `noOfRow`=@noOfRow;

	SET @query=CONCAT('DELETE FROM `',`table`,'` WHERE id=@id;');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	
	

END