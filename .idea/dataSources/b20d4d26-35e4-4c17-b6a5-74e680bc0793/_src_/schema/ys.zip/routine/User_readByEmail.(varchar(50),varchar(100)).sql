CREATE PROCEDURE `User_readByEmail`(IN `table` VARCHAR(50), IN `email` VARCHAR(100))
  BEGIN
		
	SET @email=`email`;
    
	SET @query=CONCAT('SELECT * FROM `',`table`,'` WHERE `email`=@email ;');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	

END