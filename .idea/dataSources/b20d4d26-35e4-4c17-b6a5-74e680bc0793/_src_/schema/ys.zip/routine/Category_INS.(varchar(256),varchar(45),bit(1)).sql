CREATE PROCEDURE `Category_INS`(IN `table`   VARCHAR(256), IN `name` VARCHAR(45), OUT `resultId` INT(11),
                                IN `deleted` BIT(1))
  BEGIN
  SET @name=`name`;
  SET @deleted=`deleted`;

  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(
				name,deleted
				)
				VALUES
				(
				@name,@deleted
				);'
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();
  

END