CREATE PROCEDURE `Article_INS`(IN  `table`    VARCHAR(256), IN `categoryId` INT(2), IN `title` VARCHAR(256),
                               IN  `body`     TEXT, IN `userId` INT(11), IN `noOfread` INT(11), IN `deleted` BIT(1),
                               OUT `resultId` INT(11), IN `createTime` TIMESTAMP, IN `updateTime` TIMESTAMP,
                               IN  `ip`       VARCHAR(40), IN `upvote` INT(11))
  BEGIN
  SET @categoryId=`categoryId`;  
  SET @title=`title`;
  SET @body=`body`;
  SET @createTime=`createTime`;
  SET @updateTime=`updateTime`;
  SET @userId=`userId`;
  SET @noOfread=`noOfread`;
  SET @deleted=`deleted`;
  SET @ip=`ip`;
  SET @upvote=`upvote`;
  
  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(categoryId,title,body,createTime,updateTime,userId,noOfread,deleted,ip,upvote)
                VALUES
				(@categoryId,@title,@body,@createTime,@updateTime,@userId,@noOfread,@deleted,@ip,@upvote)              
				;');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();
  

END