CREATE PROCEDURE `G_readById`(IN `table` VARCHAR(50), IN `id` INT(11))
  BEGIN
	SET @id = `id`;
	
	SET @query=CONCAT('SELECT * FROM `',`table`,'` WHERE id=@id;');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	

END