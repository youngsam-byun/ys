CREATE PROCEDURE `Article_UPD`(IN  `table`  VARCHAR(50), IN `id` INT(11), IN `categoryId` INT(2),
                               IN  `title`  VARCHAR(256), IN `body` TEXT, IN `updatedTime` TIMESTAMP,
                               IN  `userId` INT(11), IN `deleted` BIT(1), OUT `noOfRow` INT(11))
  BEGIN
  
  SET @id     = `id`    ;
  SET @categoryId=`categoryId` ;
  SET @title=`title`;
  SET @body=`body`;
  SET @updatedTime=`updatedTime`;
  SET @userId=`userId`;
  SET @deleted=`deleted`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
				     SET 
					 categoryId=@categoryId, 
					 title=@title,
					 body=@body,
					 updatedTime=@updatedTime,
					 userId=@userId,
                     deleted=@deleted 
					 WHERE id=@id;
				    '
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET @noOfRow=0;
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END