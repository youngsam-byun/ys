CREATE PROCEDURE `Category_INS`(IN `table`   VARCHAR(256), IN `name` VARCHAR(45), OUT `resultId` INT(11),
                                IN `deleted` BIT(1), IN `createTime` TIMESTAMP, IN `updateTime` TIMESTAMP)
  BEGIN
  SET @name=`name`;
  SET @createTime=`createTime`;
  SET @updateTime=`updateTime`;
  SET @deleted=`deleted`;

  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(
				name,createTime,updateTime,deleted
				)
				VALUES
				(
				@name,@createTime,@updateTime,@deleted
				);'
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();
  

END