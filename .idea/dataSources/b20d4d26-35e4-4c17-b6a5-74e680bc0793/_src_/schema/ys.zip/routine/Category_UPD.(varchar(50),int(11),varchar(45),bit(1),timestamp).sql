CREATE PROCEDURE `Category_UPD`(IN  `table`   VARCHAR(50), IN `id` INT(11), IN `name` VARCHAR(45), IN `deleted` BIT(1),
                                OUT `noOfRow` INT(11), IN `updateTime` TIMESTAMP)
  BEGIN
  
  SET @id     = `id`    ;
  SET @name=`name` ;
  SET @deleted=`deleted`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
				     SET 					 
					 name=@name,
                     updateTime=@updateTime,
                     deleted=@deleted                     
					 WHERE id=@id;
				    '
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET @noOfRow=0;
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END