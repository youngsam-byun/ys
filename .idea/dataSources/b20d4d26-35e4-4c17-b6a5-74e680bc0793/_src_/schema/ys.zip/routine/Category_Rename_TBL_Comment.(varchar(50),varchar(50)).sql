CREATE PROCEDURE `Category_Rename_TBL_Comment`(IN `oldTable` VARCHAR(50), IN `newTable` VARCHAR(50))
  BEGIN

SET @query=CONCAT('RENAME TABLE `',`oldTable`,'` TO `',`newTable`,'`;');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
END