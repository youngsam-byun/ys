CREATE PROCEDURE `Article_UPD`(IN  `table`    VARCHAR(256), IN `id` INT(11), IN `categoryId` INT(2),
                               IN  `title`    VARCHAR(256), IN `body` TEXT, IN `userId` INT(11), IN `deleted` BIT(1),
                               OUT `noOfRow`  INT(11), IN `createTime` TIMESTAMP, IN `updateTime` TIMESTAMP,
                               IN  `noOfread` INT(11), IN `ip` VARCHAR(40), IN `upvote` INT(11))
  BEGIN
  SET @id=`id`;
  SET @categoryId=`categoryId`;  
  SET @title=`title`;
  SET @body=`body`;
  SET @createTime=`createTime`;
  SET @updateTime=`updateTime`;
  SET @userId=`userId`;
  SET @noOfread=`noOfread`;
  SET @deleted=`deleted`;
  SET @ip=`ip`;
  SET @upvote=`upvote`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
					 SET 					 
                     title=@title      ,               
                     body=@body,
                     updateTime = @updateTime,
                     userId=@userId,
                     deleted=@deleted,
                     ip=@ip
					 WHERE 
					 id=@id
					 ');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	

  SET @noOfRow='';
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END