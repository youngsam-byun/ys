CREATE PROCEDURE `Category_INS`(IN `table` VARCHAR(256), IN `id` INT(2), IN `name` INT(11), OUT `resultId` INT(11))
  BEGIN
  SET @id=`id`;
  SET @name=`name`;
  SET @deleted=`deleted`;

  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(
				id,name,deleted
				)
				VALUES
				(
				@id,@name,@deleted
				);'
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();
  

END