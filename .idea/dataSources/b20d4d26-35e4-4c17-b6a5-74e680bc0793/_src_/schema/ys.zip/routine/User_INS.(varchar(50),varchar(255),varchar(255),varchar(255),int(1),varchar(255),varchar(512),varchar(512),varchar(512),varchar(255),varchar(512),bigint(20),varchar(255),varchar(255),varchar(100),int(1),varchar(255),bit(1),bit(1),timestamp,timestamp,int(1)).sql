CREATE PROCEDURE `User_INS`(IN  `table`                VARCHAR(50), IN `connectionId` VARCHAR(255),
                            IN  `providerId`           VARCHAR(255), IN `providerConnectionId` VARCHAR(255),
                            IN  `rank`                 INT(1), IN `displayName` VARCHAR(255),
                            IN  `profileUrl`           VARCHAR(512), IN `imageUrl` VARCHAR(512),
                            IN  `accessToken`          VARCHAR(512), IN `secret` VARCHAR(255),
                            IN  `refreshToken`         VARCHAR(512), IN `expireTime` BIGINT(20),
                            IN  `email`                VARCHAR(255), IN `username` VARCHAR(255),
                            IN  `password`             VARCHAR(100), IN `roleId` INT(1), IN `str` VARCHAR(255),
                            IN  `enabled`              BIT(1), IN `notLocked` BIT(1), IN `createTime` TIMESTAMP,
                            IN  `updateTime`           TIMESTAMP, IN `trial` INT(1), OUT `resultId` INT(11))
  BEGIN

  SET @connectionId =`connectionId`;
  SET @providerId =  `providerId`;
  SET @providerConnectionId = `providerConnectionId`;
  SET @rank = `rank`;
  SET @displayName = `displayName`;
  SET @profileUrl = `profileUrl`;
  SET @imageUrl = `imageUrl`;
  SET @accessToken = `accessToken`;
  SET @secret = `secret`;
  SET @refreshToken = `refreshToken`;
  SET @expireTime = `expireTime`;
-- SET @id := `id`;
  SET @email = `email`;
  SET @username = `username`;
  SET @password = `password`;
  SET @roleId = `roleId`;
  SET @str = `str`;
  SET @enabled = `enabled`;
  SET @notLocked = `notLocked`;
  SET @createTime = `createTime`;
  SET @updateTime = `updateTime`;
  SET @trial=`trial`;
	
  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(connectionId,providerId,providerConnectionId,rank,displayName
				,profileUrl,imageUrl,accessToken,secret,refreshToken
				,expireTime
				,email,username,password,roleId,
				str,enabled,notLocked
				,createTime,updateTime,trial)
				VALUES
				(@connectionId,@providerId,@providerConnectionId,@rank,@displayName
				,@profileUrl,@imageUrl,@accessToken,@secret,@refreshToken
				,@expireTime,
				 @email,@username,@password,@roleId,
				 @str,@enabled,@notLocked
				,@createTime,@updateTime,@trial)');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();

END