CREATE PROCEDURE `Article_LISTBYSEARCH`(IN `table`   VARCHAR(50), IN `pageNo` INT(11), IN `pageSize` INT(11),
                                        IN `keyword` VARCHAR(128))
  BEGIN
   	SET @pn= `pageNo`;
	SET @ps= `pageSize`;	
	SET @s= (@pn-1)*@ps;

	SET @a=0;
    SET @b=0;
	    
    SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;
        
	SET @query=CONCAT('SELECT IFNULL(MIN(`id`),0) as a, IFNULL(MAX(`id`),0) as b FROM
					   (SELECT `id` FROM `',`table`,'` WHERE ',`keyword`,' ORDER BY `id` DESC, `no` ASC, `level` ASC, `sequence` ASC  LIMIT ',@s,',',@ps,') as t	
                       INTO @a, @b ; '
					  );

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	
	
			   
    SET @query=CONCAT('SELECT * FROM `',`table`,'` WHERE (id BETWEEN @a AND @b) AND ',`keyword`,' ORDER BY `id` DESC, `no` ASC, `level` ASC, `sequence` ASC');
    
	PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	
    
    SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;
    
END