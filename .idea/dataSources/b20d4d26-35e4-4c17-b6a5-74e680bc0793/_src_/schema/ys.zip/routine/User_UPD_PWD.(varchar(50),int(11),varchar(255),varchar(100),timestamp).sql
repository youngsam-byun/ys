CREATE PROCEDURE `User_UPD_PWD`(IN `table`    VARCHAR(50), IN `id` INT(11), IN `email` VARCHAR(255),
                                IN `password` VARCHAR(100), IN `updateTime` TIMESTAMP, OUT `noOfRow` INT(11))
  BEGIN

  
  SET @id = `id`;
  SET @email = `email`;
  SET @password=`password`;
  SET @updateTime=`updateTime`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
				SET 
                password=@password,
                updateTime=@updateTime
                WHERE
                id=@id OR email=@email;
                ');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET @noOfRow='';
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id OR email=@email;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END