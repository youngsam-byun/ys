CREATE PROCEDURE `getListAll`(IN `table` VARCHAR(50))
  BEGIN

	SET @query=CONCAT('SELECT * FROM `',`table`,'` ORDER BY `id` DESC ');

    PREPARE stmt FROM @query;
	EXECUTE stmt;	
    DEALLOCATE PREPARE stmt;	


END