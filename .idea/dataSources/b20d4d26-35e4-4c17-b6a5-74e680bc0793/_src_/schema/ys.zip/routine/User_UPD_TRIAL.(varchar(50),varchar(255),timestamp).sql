CREATE PROCEDURE `User_UPD_TRIAL`(IN  `table`   VARCHAR(50), IN `email` VARCHAR(255), IN `updateTime` TIMESTAMP,
                                  OUT `noOfRow` INT(11))
  BEGIN

  SET @email = `email`;
  SET @updateTime=`updateTime`;
  	
  SET @query=CONCAT('UPDATE `',`table`,'` 
				SET 
                trial=trial+1,
                updateTime=@updateTime  
                WHERE
                email=@email;
                ');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET @noOfRow='';
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE email=@email;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END