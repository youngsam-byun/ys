CREATE PROCEDURE `Article_INS`(IN  `table`    VARCHAR(256), IN `categoryId` INT(2), IN `no` INT(11),
                               IN  `level`    TINYINT(2), IN `sequence` TINYINT(2), IN `title` VARCHAR(256),
                               IN  `body`     TEXT, IN `createdTime` TIMESTAMP, IN `updatedTime` TIMESTAMP,
                               IN  `userId`   INT(11), IN `noOfread` INT(11), IN `deleted` BIT(1),
                               OUT `resultId` INT(11))
  BEGIN
  SET @categoryId=`categoryId`;
  SET @no=`no`;
  SET @level=`level`;
  SET @sequence=`sequence`;
  SET @title=`title`;
  SET @body=`body`;
  SET @createdTime=`createdTime`;
  SET @updatedTime=`updatedTime`;
  SET @userId=`userId`;
  SET @noOfread=`noOfread`;
  SET @deleted=`deleted`;

  SET @query=CONCAT('INSERT INTO `',`table`,'` 
				(
				categoryId,no,level,sequence,title,body,createdTime,updatedTime,userId,noOfread,deleted
				)
				VALUES
				(
				@categoryId,@no,@level,@sequence,@title,@body,@createdTime,@updatedTime,@userId,@noOfread,@deleted
				);'
				);

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	
  
  SET `resultId`=LAST_INSERT_ID();
  

END