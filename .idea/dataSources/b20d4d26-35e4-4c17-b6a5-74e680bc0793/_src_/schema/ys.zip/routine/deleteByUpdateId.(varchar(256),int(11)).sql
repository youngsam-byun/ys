CREATE PROCEDURE `deleteByUpdateId`(IN `table` VARCHAR(256), IN `id` INT(11), OUT `noOfRow` INT(11))
  BEGIN
  SET @id=`id`;
	
  SET @query=CONCAT('UPDATE `',`table`,'` 
					 SET 					                      
                     deleted=true
					 WHERE 
					 id=@id
					 ');

  PREPARE stmt FROM @query;
  EXECUTE stmt;	
  DEALLOCATE PREPARE stmt;	

  SET @noOfRow='';
  SET	@query2=CONCAT('SELECT COUNT(id) INTO @noOfRow FROM `',`table`,'` WHERE id=@id;');
  PREPARE stmt2 FROM @query2;
  EXECUTE stmt2;	
  DEALLOCATE PREPARE stmt2;	

  SET `noOfRow`=@noOfRow;

END